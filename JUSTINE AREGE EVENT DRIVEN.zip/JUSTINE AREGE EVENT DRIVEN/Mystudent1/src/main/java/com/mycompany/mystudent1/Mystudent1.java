/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mystudent1;

/**
 *
 * @author Hunter
 */
public class Mystudent1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
